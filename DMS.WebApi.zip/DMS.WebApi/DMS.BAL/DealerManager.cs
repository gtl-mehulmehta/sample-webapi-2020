﻿using DMS.BAL.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DMS.Models;
using DMS.DAL.Repository;

namespace DMS.BAL
{
    public class DealerManager : IDealerManager
    {
        /// <summary>
        /// common object
        /// </summary>
        private readonly IDealerRepository _dealerRepository;

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dealerRepository"></param>
        public DealerManager(IDealerRepository dealerRepository)
        {
            _dealerRepository = dealerRepository;
        }

        public Dealer GetDealer()
        {
            //Dealer dealer = new Dealer
            //{
            //    Id=7,
            //    DealerName= "MG",
            //    DealerCity= "Ahmedabad"
            //};

            ///TODO: Call dealer repository from DAL
            ///
            var dealer = _dealerRepository.GetDealer();
            return dealer;
        }
    }
}
