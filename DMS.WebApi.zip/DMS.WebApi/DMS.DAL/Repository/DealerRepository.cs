﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DMS.Models;

namespace DMS.DAL.Repository
{
    public class DealerRepository : IDealerRepository
    {
        public Dealer GetDealer()
        {
            Dealer dealer = new Dealer
            {
                Id = 8,
                DealerName = "BMW",
                DealerCity = "Mumbai"
            };
            //TODO: fetch data from DB

            return dealer;
        }
    }
}
