﻿using DMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS.DAL.Repository
{
    public interface IDealerRepository
    {
        Dealer GetDealer();
    }
}
