﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DMS.Models;

namespace DMS.DAL.Repository
{
    public class DealerRepository : IDealerRepository
    {
        private readonly Database.sampleEntities _dbContext;

        public DealerRepository()
        {
            _dbContext = new Database.sampleEntities();
        }

        public string CreateDealer(Dealer model)
        {
            try
            {
                if (model != null)
                {
                    Database.Dealer entity = new Database.Dealer();

                    entity.DealerName = model.DealerName;
                    entity.City = model.City;
                    entity.Country = model.Country;
                    entity.DealerContact = model.DealerContact;
                    entity.CreatedDate = DateTime.Now;

                    _dbContext.Dealers.Add(entity);
                    _dbContext.SaveChanges();

                    return "Successfully added!";
                }

                return "Model is null!";

            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string DeleteDealer(int Id)
        {
            try
            {

                var entity = _dbContext.Dealers.Find(Id);

                if (entity != null)
                {

                    _dbContext.Dealers.Remove(entity);
                    _dbContext.SaveChanges();

                    return "Deleted!";
                }

                return "No data found";

            }
            catch (Exception ex)
            {

                return ex.Message;
            }
        }

        public List<Dealer> GetAllDealer()
        {
            var entities = _dbContext.Dealers.ToList();

            List<Dealer> list = new List<Dealer>();

            if (entities != null)
            {
                foreach (var item in entities)
                {
                    Dealer dealer = new Dealer();

                    ///TODO: Problem why manually?                     
                    dealer.Id = item.Id;
                    dealer.DealerName = item.DealerName;
                    dealer.City = item.City;
                    dealer.Country = item.Country;
                    dealer.DealerContact = item.DealerContact;
                    dealer.CreatedDate = item.CreatedDate;
                    dealer.UpdateDate = item.UpdatedDate;

                    list.Add(dealer);

                }
            }


            return list;

        }

        //public Dealer GetDealer()
        //{
        //    //Dealer dealer = new Dealer
        //    //{
        //    //    Id = 8,
        //    //    DealerName = "BMW",
        //    //    DealerCity = "Mumbai"
        //    //};
        //    //TODO: fetch data from DB

        //    return dealer;
        //}

        public Dealer GetDealer(int Id)
        {
            var entity = _dbContext.Dealers.Find(Id);


            Dealer dealer = new Dealer();

            if (entity != null)
            {
                ///TODO: Problem why manually?                     
                dealer.Id = entity.Id;
                dealer.DealerName = entity.DealerName;
                dealer.City = entity.City;
                dealer.Country = entity.Country;
                dealer.DealerContact = entity.DealerContact;
                dealer.CreatedDate = entity.CreatedDate;
                dealer.UpdateDate = entity.UpdatedDate;
            }

            return dealer;
        }

        public string UpdateDealer(Dealer model)
        {
            try
            {

                var entity = _dbContext.Dealers.Find(model.Id);

                if (entity != null)
                {                   

                    entity.DealerName = model.DealerName;
                    entity.City = model.City;
                    entity.Country = model.Country;
                    entity.DealerContact = model.DealerContact;

                    entity.UpdatedDate = DateTime.Now;

                    
                    _dbContext.SaveChanges();

                    return "Updated!";
                }

                return "No data found";

            }
            catch (Exception ex)
            {

                return ex.Message;
            }
        }
    }
}
