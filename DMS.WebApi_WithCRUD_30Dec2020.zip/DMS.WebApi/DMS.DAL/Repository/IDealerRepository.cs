﻿using DMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS.DAL.Repository
{
    public interface IDealerRepository
    {
        Dealer GetDealer(int Id);
        List<Dealer> GetAllDealer();
        string CreateDealer(Dealer model);
        string UpdateDealer(Dealer model);
        string DeleteDealer(int Id);

    }
}
