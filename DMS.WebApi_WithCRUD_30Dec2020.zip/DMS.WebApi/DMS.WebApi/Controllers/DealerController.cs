﻿using DMS.BAL;
using DMS.BAL.Interface;
using DMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DMS.WebApi.Controllers
{
    public class DealerController : ApiController
    {
        private readonly IDealerManager _dealerManager;


        public DealerController(IDealerManager dealerManager)
        {
            _dealerManager = dealerManager;
        }

        // GET: api/Dealer
        public List<Dealer> Get()
        {
            //{
            //    ///TODO: Call dealer via BAL

            //    //DealerManager dealermanager = new DealerManager();
            //    //dealermanager.GetDealer();

            //    var dealer= _dealerManager.GetDealer();

            //    return dealer;
            // return new string[] { "value1", "value2" };
            return _dealerManager.GetAllDealer();
        }

        // GET: api/Dealer/5
        public Dealer Get(int id)
        {
            return _dealerManager.GetDealer(id);
        }

        // POST: api/Dealer
        public string Post([FromBody]Dealer model)
        {
            return _dealerManager.CreateDealer(model);
        }

        // PUT: api/Dealer/5
        public string Put([FromBody]Dealer model)
        {
            return _dealerManager.UpdateDealer(model);
        }

        // DELETE: api/Dealer/5
        public string Delete(int id)
        {
            return _dealerManager.DeleteDealer(id);
        }
    }
}
